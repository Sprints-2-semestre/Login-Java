import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Login {
    public static void main(String[] args) {
        Scanner leitorNum = new Scanner(System.in);
        Scanner leitorText = new Scanner(System.in);
        List<String> emailCadastrados = new ArrayList<>();
        List<String> senhasCadastradas = new ArrayList<>();
        List<String> nomesCadastrados = new ArrayList<>();

        emailCadastrados.add("mariana@farmacos.com");
        emailCadastrados.add("tiaki@farmacos.com");

        senhasCadastradas.add("mariana123");
        senhasCadastradas.add("tiaki123");

        nomesCadastrados.add("Mariana");
        nomesCadastrados.add("Tiaki");


        Integer opcoes;
        String cadastroNome;
        String cadastroEmail;
        String cadastroSenha;
        String cadastroSenhaConfirma;

        do {
            System.out.println();
            System.out.println(""" 
                    \n--------------------------------------------------------------------------------------------
                    |  Bem-vindo ao Sistema de Login da Fármacos! Para continuar siga as instruções do console.|
                    --------------------------------------------------------------------------------------------
                    |                                         DIGITE:                                          |
                    |------------------------------------------------------------------------------------------|
                    | 1 - Cadastro                                                                             |
                    | 2 - Login                                                                                |
                    | 3 - Sair                                                                                 |
                    --------------------------------------------------------------------------------------------""");
            opcoes = leitorNum.nextInt();

            if (opcoes.equals(1)) {
                System.out.println("----------------- Cadastro ------------------");
                System.out.println("Digite seu nome: ");
                cadastroNome = leitorText.nextLine();
                nomesCadastrados.add(cadastroNome);

                System.out.println("Digite seu e-mail: ");
                cadastroEmail = leitorText.nextLine();
                emailCadastrados.add(cadastroEmail);

                System.out.println("Digite sua nova senha: ");
                cadastroSenha = leitorText.nextLine();
                senhasCadastradas.add(cadastroSenha);

                System.out.println("Confirme sua nova senha: ");
                cadastroSenhaConfirma = leitorText.nextLine();

                while (!cadastroSenha.equals(cadastroSenhaConfirma)) {
                    System.out.println("Suas senhas não combinam, confira os dados e tente novamente.");

                    System.out.println("Digite sua nova senha: ");
                    cadastroSenha = leitorText.nextLine();
                    System.out.println("Confirme sua nova senha: ");
                    cadastroSenhaConfirma = leitorText.nextLine();
                }

                System.out.println("Você foi cadastrado com sucesso.");

            } else if (opcoes.equals(2)) {

                String nome = nomesCadastrados.get(0);
                String senha = senhasCadastradas.get(0);

                System.out.println("--------------Login-------------------");
                System.out.println("Digite seu e-mail: ");
                String email = leitorText.nextLine();

                System.out.println("Digite sua senha: ");
                String senhaDigitada = leitorText.nextLine();

                Integer indice = -1;
                for (int i = 0; i < emailCadastrados.size(); i++) {
                    if (emailCadastrados.get(i).equals(email)){
                        indice = i;
                    }
                }

                if (!indice.equals(-1)) {
                    nome = nomesCadastrados.get(indice);
                    senha = senhasCadastradas.get(indice);

                    Integer contador = 1;
                    while (!senhaDigitada.equals(senha) && contador < 3){
                        System.err.println("Senha incorreta. Tente novamente. \n Restam " + (3-contador) + " tentativas.");
                        contador++;
                        senhaDigitada = leitorText.nextLine();
                    }

                    if (senhaDigitada.equals(senha)){
                        System.out.println("\nLogin efetuado com sucesso.\nOlá " + nome + " que bom te ver novamente!");
                        opcoes = 3;
                    } else if (contador.equals(3)) {
                        System.out.println("Acesso bloqueado. Tente novamente mais tarde.");
                    }
                } else {
                    System.out.println("Usuario não encontrado no sistema. Cadastre-se já!");
                }

            } else if (opcoes.equals(3)) {
                System.out.println("Desconectando... Obrigado por escolher a Fármacos!");
            } else {
                System.out.println("Opção invalida.");
            }
        } while (!opcoes.equals(3));

        leitorNum.close();
        leitorText.close();
    }
}
